
// هذا ملف JavaScript مخصص للمشروع

document.addEventListener("DOMContentLoaded", function() {
    // Validation for Login Form
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent default form submission initially

            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;

            if (username.trim() === "" || password.trim() === "") {
                alert("الرجاء إدخال اسم المستخدم وكلمة المرور.");
            } else {
                // Temporary: Redirect to index.html after successful (client-side) validation
                alert("تم تسجيل الدخول بنجاح (مؤقتًا)!");
                window.location.href = "index.html";
            }
        });
    }

    // Validation for Register Form
    const registerForm = document.getElementById("registerForm");
    if (registerForm) {
        registerForm.addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent default form submission initially

            const regUsername = document.getElementById("regUsername").value;
            const regEmail = document.getElementById("regEmail").value;
            const regPassword = document.getElementById("regPassword").value;
            const confirmPassword = document.getElementById("confirmPassword").value;

            if (regUsername.trim() === "" || regEmail.trim() === "" || regPassword.trim() === "" || confirmPassword.trim() === "") {
                alert("الرجاء تعبئة جميع الحقول.");
                return;
            }

            // Basic email validation
            const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
            if (!emailPattern.test(regEmail)) {
                alert("الرجاء إدخال بريد إلكتروني صحيح.");
                return;
            }

            // Password match validation
            if (regPassword !== confirmPassword) {
                alert("كلمتا المرور غير متطابقتين.");
                return;
            }

            // Password length (example)
            if (regPassword.length < 6) {
                alert("يجب أن تكون كلمة المرور 6 أحرف على الأقل.");
                return;
            }

            // Temporary: Redirect to login.html after successful (client-side) registration
            alert("تم إنشاء الحساب بنجاح (مؤقتًا)! سيتم توجيهك لصفحة تسجيل الدخول.");
            window.location.href = "login.html";
        });
    }
});
